function setup() {
  noCanvas();

  // Criando o cabeçalho
  createDiv('GUIMINAMFLIX').style('font-size', '32px').style('font-weight', 'bold');

  // Seção de chamada
  let chamadaDiv = createDiv();
  chamadaDiv.html(`
    <h1>ATRAVÉS DO ARANHAVERSO</h1>
    <p>#homem-aranha</p>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/gt_fAE1Eg2Q?si=EEv-tsY_b1B2OwKE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
  `);

  // Seção de filmes e séries
  let categoriaDiv = createDiv();
  categoriaDiv.html('<h2>Filmes e séries</h2>');

  // Lista de links com imagens
  let links = [
    {href: "https://www.youtube.com/watch?v=cs15QqG6Gjc", img: "https://img.youtube.com/vi/cs15QqG6Gjc/maxresdefault.jpg"},
    {href: "https://www.youtube.com/watch?v=nCmIwcycUJ8", img: "https://img.youtube.com/vi/nCmIwcycUJ8/maxresdefault.jpg"},
    {href: "https://www.youtube.com/watch?v=FvRmEapoHRc", img: "https://img.youtube.com/vi/FvRmEapoHRc/maxresdefault.jpg"},
    {href: "https://www.youtube.com/watch?v=Ipkw_hWW-Hw", img: "https://img.youtube.com/vi/Ipkw_hWW-Hw/maxresdefault.jpg"},
    {href: "https://www.youtube.com/watch?v=d4DzMNGoyis", img: "https://img.youtube.com/vi/d4DzMNGoyis/maxresdefault.jpg"},
  ];

  let imgsDiv = createDiv();
  links.forEach(link => {
    let a = createA(link.href);
    let img = createImg(link.img);
    a.child(img);
    imgsDiv.child(a);
  });
}